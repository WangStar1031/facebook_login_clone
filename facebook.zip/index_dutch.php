<!DOCTYPE html>
<!-- saved from url=(0079)https://m.facebook.com/?refsrc=https%3A%2F%2Fm.facebook.com%2Flanguage.php&_rdr -->
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Facebook - Meld je aan of registreer je</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1.0001,maximum-scale=1.0001,viewport-fit=cover">
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/a36n03MSzp1.png" rel="apple-touch-icon-precomposed" sizes="120x120">
    <meta name="referrer" content="default" id="meta_referrer">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link type="text/css" rel="stylesheet" href="./Facebook - Meld je aan of registreer je_files/fyiknpNTJFq.css" data-bootloader-hash="YO2eE">
    <link type="text/css" rel="stylesheet" href="./Facebook - Meld je aan of registreer je_files/dUQNRIN2MLK.css" data-bootloader-hash="/hdmF">

    <meta name="description" content="Maak een account of meld je aan bij Facebook. Maak contact met vrienden, familie en andere mensen die je kent. Deel foto&#39;s en video&#39;s, stuur...">
    <link rel="canonical" href="https://www.facebook.com/">
</head>

<body tabindex="0" class="touch x2 ios sf mSafari _fzu _50-3 iframe acw portrait" style="min-height: 735px; background-color: rgb(255, 255, 255);">
    <div id="viewport" data-kaios-focus-transparent="1" style="min-height: 735px;">
        <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
        <div id="page" class="">
            <div class="_129_" id="header-notices"></div>
            <div class="_7om2 _52we _52z5" id="header">
                <div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href="https://m.facebook.com/login/?refid=8"><i class="img sp_sJW2P2tLEpz_2x sx_a537e4"><u>facebook</u></i></a></div>
            </div>
            <div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 735px;">
                <div class="_7om2">
                    <div class="_4g34" id="u_0_0">
                        <div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice">
                            <div class="_52jd"></div>
                        </div>
                        <div class="aclb _4-4l">
                            <div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element">
                                <div class="_qw9 grouped aclb">
                                    <a href="https://m.facebook.com/click.php?redir_url=http%3A%2F%2Fitunes.apple.com%2Fapp%2Ffacebook%2Fid284882215%3Freferrer_params%255Blink_source%255D%3Dfb_app_banner&amp;app_id=6628568379&amp;cref=mb&amp;no_fw=1&amp;refid=8" target="_top" class="touchableArea first last area touchable acy apl abt abb" data-sigil="touchable marea">
                                        <div class="ib cc"><i class="img l img _2sxw" style="background-image: url(&#39;https\3a //static.xx.fbcdn.net/rsrc.php/v3/yP/r/JJsC9S33ata.png&#39;);background-repeat:no-repeat;background-size:100% 100%;-webkit-background-size:100% 100%;width:18px;height:32px;"></i>
                                            <div class="c"><span class="fcl">Installeer Facebook voor iPhone en surf sneller.</span></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="_5rut">
                                <form method="post" action="https://m.facebook.com/login/device-based/login/async/?refsrc=https%3A%2F%2Fm.facebook.com%2Flanguage.php&amp;lwv=100" class="mobile-login-form _5spm" id="login_form" novalidate="1" data-sigil="m_login_form" data-autoid="autoid_2">
                                    <input type="hidden" name="lsd" value="AVoC---5" autocomplete="off">
                                    <input type="hidden" name="jazoest" value="2517" autocomplete="off">
                                    <input type="hidden" name="m_ts" value="1575761552">
                                    <input type="hidden" name="li" value="kDbsXbuUF4FDubCY7FtFvuf5">
                                    <input type="hidden" name="try_number" value="0" data-sigil="m_login_try_number">
                                    <input type="hidden" name="unrecognized_tries" value="0" data-sigil="m_login_unrecognized_tries">
                                    <div id="user_info_container" data-sigil="user_info_after_failure_element"></div>
                                    <div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div>
                                    <div id="otp_retrieve_desc_container"></div>
                                    <div class="_56be _5sob">
                                        <div class="_55wo _55x2 _56bf">
                                            <div id="email_input_container">
                                                <input autocorrect="off" autocapitalize="off" type="email" class="_56bg _4u9z _5ruq" autocomplete="on" id="m_login_email" name="email" placeholder="Mobiele telefoonnummer of e-mailadres" data-sigil="m_login_email">
                                            </div>
                                            <div>
                                                <div class="_1upc _mg8" data-sigil="m_login_password">
                                                    <div class="_7om2">
                                                        <div class="_4g34 _5i2i _52we">
                                                            <div class="_5xu4">
                                                                <input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="m_login_password" name="pass" placeholder="Wachtwoord" type="password" data-sigil="password-plain-text-toggle-input">
                                                            </div>
                                                        </div>
                                                        <div class="_5s61 _216i _5i2i _52we">
                                                            <div class="_5xu4">
                                                                <div class="_2pi9" style="display:none" id="u_0_1"><a href="https://m.facebook.com/?refsrc=https%3A%2F%2Fm.facebook.com%2Flanguage.php&amp;_rdr#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2">VERBERGEN</span><span class="mfss" id="u_0_3">WEERGEVEN</span></a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="_2pie" style="text-align:center;">
                                        <div id="u_0_4" data-sigil="login_password_step_element">
                                            <button type="button" value="Aanmelden" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" data-sigil="touchable login_button_block m_login_button" data-autoid="autoid_4"><span class="_55sr">Aanmelden</span></button>
                                        </div>
                                        <div class="_7eif" id="oauth_login_button_container" style="display:none"></div>
                                        <div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div>
                                        <div id="otp_button_elem_container"></div>
                                    </div>
                                    <input type="hidden" name="prefill_contact_point" id="prefill_contact_point">
                                    <input type="hidden" name="prefill_source" id="prefill_source">
                                    <input type="hidden" name="prefill_type" id="prefill_type">
                                    <input type="hidden" name="first_prefill_source" id="first_prefill_source">
                                    <input type="hidden" name="first_prefill_type" id="first_prefill_type">
                                    <input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false">
                                    <input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false">
                                    <input type="hidden" name="is_smart_lock" id="is_smart_lock" value="false">
                                    <div class="_xo8"></div>
                                    <noscript>
                                        <input type="hidden" name="_fb_noscript" value="true" />
                                    </noscript>
                                </form>
                                <div>
                                    <div class="_43mg _8qtb"><span class="_43mh">of</span></div>
                                    <div class="_52jj _5t3b" id="u_0_5"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_3">Nieuw account maken</a></div>
                                </div>
                                <div>
                                    <div class="other-links _8p_m">
                                        <ul class="_5pkb _55wp">
                                            <li><span class="mfss fcg"><a tabindex="0" href="https://m.facebook.com/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;r&amp;cuid&amp;ars=facebook_login&amp;lwv=100&amp;refid=8" id="forgot-password-link">Wachtwoord vergeten?</a></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="display:none"></div><span><img src="./Facebook - Meld je aan of registreer je_files/hsts-pixel.gif" width="0" height="0" style="display:none"></span>
                <div class="_55wr _5ui2" data-sigil="m_login_footer">
                    <div class="_5dpw">
                        <div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
                            <div class="_7om2">
                                <div class="_4g34"><span class="_52jc _52j9 _52jh _3ztb">Nederlands</span>
                                    <div class="_3ztc"><span class="_52jc"><a href="https://m.facebook.com/a/language.php?l=zh_CN&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;gfid=AQDFRJEDCIexTa-U&amp;refid=8" data-locale="zh_CN" data-sigil="change_language">中文(简体)</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="https://m.facebook.com/a/language.php?l=es_LA&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;gfid=AQC4r8_LAScBMnhu&amp;refid=8" data-locale="es_LA" data-sigil="change_language">Español</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="https://m.facebook.com/a/language.php?l=fr_FR&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;gfid=AQC-wAfREU7CJGF2&amp;refid=8" data-locale="fr_FR" data-sigil="change_language">Français (France)</a></span></div>
                                </div>
                                <div class="_4g34">
                                    <div class="_3ztc"><span class="_52jc"><a href="https://m.facebook.com/a/language.php?l=en_US&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;gfid=AQB2Q_tWdOqNYNzh&amp;refid=8" data-locale="en_US" data-sigil="change_language">English (US)</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="https://m.facebook.com/a/language.php?l=ja_JP&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;gfid=AQB5qb0lzZ8Wg7er&amp;refid=8" data-locale="ja_JP" data-sigil="change_language">日本語</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a href="https://m.facebook.com/a/language.php?l=pt_BR&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;gfid=AQCvGSBApnZrwsJR&amp;refid=8" data-locale="pt_BR" data-sigil="change_language">Português (Brasil)</a></span></div>
                                    <a href="https://m.facebook.com/language.php?n=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fm.facebook.com%252Flanguage.php&amp;refid=8">
                                        <div class="_3j87 _1rrd _3ztd" aria-label="Volledige lijst van talen" data-sigil="more_language"><i class="img sp_sJW2P2tLEpz_2x sx_ceef21"></i></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="_5ui4"><span class="mfss fcg">Facebook, Inc.</span></div>
                    </div>
                </div>
            </div>
            <div class=""></div>
            <div class="viewportArea _2v9s" style="display:none" id="u_0_6" data-sigil="marea">
                <div class="_5vsg" id="u_0_7" style="max-height: 206px;"></div>
                <div class="_5vsh" id="u_0_8" style="max-height: 367px;"></div>
                <div class="_5v5d fcg">
                    <div class="_2so _2sq _2ss img _50ch" data-animtype="3" data-sigil="m-loading-indicator-root">
                        <div class="_2sr" data-sigil="m-loading-indicator-animate"></div>
                    </div>Laden...</div>
            </div>
            <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
                <div class="container">
                    <div class="image"></div>
                    <div class="message" data-sigil="error-message"></div><a class="link" data-sigil="MPageError:retry">Opnieuw proberen</a></div>
            </div>
        </div>
    </div>
    <div id="static_templates">
        <div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_1">
            <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
                <div class="_7om2 _52we">
                    <div class="_5s61">
                        <div class="_52z7">
                            <button type="submit" value="Annuleren" class="cancelButton btn btnD bgb mfss touchable" id="u_0_a" data-sigil="dialog-cancel-button">Annuleren</button>
                            <button type="submit" value="Terug" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Terug" id="u_0_b" data-sigil="dialog-back-button"><i class="img sp_sJW2P2tLEpz_2x sx_914267" style="margin-top: 2px;"></i></button>
                        </div>
                    </div>
                    <div class="_4g34">
                        <div class="_52z6">
                            <div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">Laden...</div>
                        </div>
                    </div>
                    <div class="_5s61">
                        <div class="_52z8" id="modalDialogHeaderButtons"></div>
                    </div>
                </div>
            </div>
            <div class="modalDialogView" id="modalDialogView"></div>
            <div class="_5v5d _5v5e fcg" id="dialogSpinner">
                <div class="_2so _2sq _2ss img _50ch" data-animtype="3" id="u_0_9" data-sigil="m-loading-indicator-root">
                    <div class="_2sr" data-sigil="m-loading-indicator-animate"></div>
                </div>Laden...</div>
        </div>
    </div>
    <link rel="preload" href="./Facebook - Meld je aan of registreer je_files/ycKM-0cVxwH.js.download" as="script">
    <link rel="preload" href="./Facebook - Meld je aan of registreer je_files/PY1DH87KV_E.js.download" as="script">
    <link rel="preload" href="./Facebook - Meld je aan of registreer je_files/oUIbtw1b6Wv.js.download" as="script">
</body>

</html>